import React, { useState } from 'react';

// Import Ionicons for the icons used in the bottom tab navigation
import { Ionicons } from '@expo/vector-icons';

// Import React Navigation components
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';

// Import the different screens of the application
import HomeScreen from './frontend/Home';
import ProfileScreen from './frontend/ProfileScreen';
import SettingsScreen from './frontend/SettingsScreen';
import ContactScreen from './frontend/ContantScreen';

// Import the application's theme definitions
import { themes } from './frontend/StyleSheet';

// Create the bottom tab navigator
const Tab = createBottomTabNavigator();

// Map simple screen keys to their actual navigation screen names
const screenRoutes = {
  home: 'Home',
  profile: 'Profile',
  settings: 'Settings',
  contact: 'Contact',
};

export default function App() {
  // State used to switch between bright and calm themes
  const [isBrightMode, setIsBrightMode] = useState(true);

  // Select the current theme based on the bright mode state
  const theme = isBrightMode ? themes.bright : themes.calm;

  // Configure the appearance and behavior of the bottom tab bar
  const screenOptions = ({ route }) => ({
    // Hide the default header at the top of each screen
    headerShown: false,

    // Color of the currently selected tab
    tabBarActiveTintColor: theme.primaryDark,

    // Color of tabs that are not selected
    tabBarInactiveTintColor: theme.muted,

    // Styling for the bottom navigation bar
    tabBarStyle: {
      backgroundColor: theme.surface,
      borderTopColor: theme.border,
    },

    // Styling for the labels displayed below the icons
    tabBarLabelStyle: {
      fontSize: 11,
      fontWeight: '700',
    },

    // Set an icon for each navigation tab
    tabBarIcon: ({ color, size }) => {
      // Match each screen name with an Ionicons icon
      const icons = {
        Home: 'home-outline',
        Profile: 'person-outline',
        Settings: 'settings-outline',
        Contact: 'chatbubble-ellipses-outline',
      };

      // Render the icon using the current tab's color and size
      return (
        <Ionicons
          name={icons[route.name]}
          size={size}
          color={color}
        />
      );
    },
  });

  // Create common props that will be passed to each screen
  const screenProps = (navigation) => ({
    // Give each screen access to the currently selected theme
    theme,

    // Helper function for navigating between screens
    goToScreen: (screenName) =>
      navigation.navigate(screenRoutes[screenName]),
  });

  return (
    // NavigationContainer manages the application's navigation state
    <NavigationContainer>
      {/* Bottom tab navigator containing all main application screens */}
      <Tab.Navigator screenOptions={screenOptions}>

        {/* Home tab */}
        <Tab.Screen name="Home">
          {({ navigation }) => (
            <HomeScreen {...screenProps(navigation)} />
          )}
        </Tab.Screen>

        {/* Profile tab */}
        <Tab.Screen name="Profile">
          {({ navigation }) => (
            <ProfileScreen {...screenProps(navigation)} />
          )}
        </Tab.Screen>

        {/* Settings tab */}
        <Tab.Screen name="Settings">
          {({ navigation }) => (
            <SettingsScreen
              {...screenProps(navigation)}

              // Pass the current theme mode to the Settings screen
              isBrightMode={isBrightMode}

              // Toggle between bright and calm themes
              onToggleBrightMode={() =>
                setIsBrightMode((current) => !current)
              }
            />
          )}
        </Tab.Screen>

        {/* Contact tab */}
        <Tab.Screen name="Contact">
          {({ navigation }) => (
            <ContactScreen {...screenProps(navigation)} />
          )}
        </Tab.Screen>

      </Tab.Navigator>
    </NavigationContainer>
  );
}