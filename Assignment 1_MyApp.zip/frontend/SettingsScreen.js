import React from 'react';
import {
  ScrollView,
  Switch,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { useAudioPlayer } from 'expo-audio';

import { createStyles } from './StyleSheet';

export default function SettingsScreen({
  goToScreen,
  theme,
  isBrightMode,
  onToggleBrightMode,
}) {
  const styles = createStyles(theme);
  const tapPlayer = useAudioPlayer(require('../assets/button-tap.wav'));

  const playTap = () => {
    tapPlayer.seekTo(0);
    tapPlayer.play();
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.eyebrow}>Your preferences</Text>
      <Text style={styles.title}>Settings</Text>
      <Text style={styles.subtitle}>
        Make the app feel a little more like you.
      </Text>

      <View style={styles.card}>
        <View style={styles.settingRow}>
          <View style={styles.settingCopy}>
            <Text style={styles.settingLabel}>Bright mode</Text>
            <Text style={styles.settingDescription}>
              {isBrightMode ? 'Warm, light, and cheerful' : 'Soft contrast for quieter evenings'}
            </Text>
          </View>
          <Switch
            value={isBrightMode}
            onValueChange={(value) => {
              playTap();
              onToggleBrightMode(value);
            }}
            trackColor={{ false: theme.border, true: theme.accent }}
            thumbColor={isBrightMode ? theme.primary : '#F4F4F4'}
            accessibilityLabel="Toggle bright mode"
          />
        </View>
      </View>

      <TouchableOpacity
        style={styles.button}
        onPress={() => {
          playTap();
          goToScreen('home');
        }}
      >
        <Text style={styles.buttonText}>Back to home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
