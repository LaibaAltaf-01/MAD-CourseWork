import React, { useState } from 'react';
import {
  Image,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';
import { useAudioPlayer } from 'expo-audio';

import { createStyles } from './StyleSheet';

const profileImage = {
  uri: 'https://cdn-icons-png.flaticon.com/512/6997/6997662.png',
};

export default function ProfileScreen({ goToScreen, theme }) {
  const styles = createStyles(theme);
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const tapPlayer = useAudioPlayer(require('../assets/button-tap.wav'));

  const playTap = () => {
    tapPlayer.seekTo(0);
    tapPlayer.play();
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">
        <View style={styles.card}>
          <Image source={profileImage} style={styles.profileImage} />
          <Text style={styles.title}>Your profile</Text>
          <Text style={styles.subtitle}>Tell us a little about the person behind the smile.</Text>

          <TextInput
            style={styles.input}
            placeholder="Your name"
            placeholderTextColor={theme.muted}
            value={name}
            onChangeText={setName}
          />
          <TextInput
            style={styles.input}
            placeholder="Your age"
            placeholderTextColor={theme.muted}
            value={age}
            onChangeText={setAge}
            keyboardType="numeric"
            inputMode="numeric"
          />

          <View style={styles.highlightCard}>
            <View style={styles.highlightHeader}>
              <Text style={styles.highlightLabel}>Viva Ready</Text>
              <Text style={styles.highlightBadge}>★</Text>
            </View>

            <View style={styles.highlightGrid}>
              <View style={styles.miniCard}>
                <Text style={styles.miniLabel}>Idea</Text>
                <Text style={styles.miniValue}>Creative</Text>
              </View>
              <View style={styles.miniCard}>
                <Text style={styles.miniLabel}>Style</Text>
                <Text style={styles.miniValue}>Smart</Text>
              </View>
              <View style={styles.miniCard}>
                <Text style={styles.miniLabel}>Pitch</Text>
                <Text style={styles.miniValue}>Confident</Text>
              </View>
            </View>
          </View>

          <Text style={styles.liveLabel}>Live preview</Text>
          <Text style={styles.liveValue}>Name: {name || 'Your name will appear here'}</Text>
          <Text style={styles.liveValue}>Age: {age || 'Your age will appear here'}</Text>
        </View>

        <TouchableOpacity
          style={styles.button}
          onPress={() => {
            playTap();
            goToScreen('home');
          }}
        >
          <Text style={styles.buttonText}>Back to home</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}
